@extends('main')

@section('content')

     @include('components.trending')

    <div class="container mt-5" >
        <hr>
    </div>

     @include('components.comingsoon')


     <div class="container mt-5" >
        <hr>
    </div>

    <!-- @include('components.popular')


    <div class="container mt-5" >
        <hr>
    </div>

    @include('components.allTimePopular')

    <div class="container mt-5" >
        <br>
    </div> -->


@endsection