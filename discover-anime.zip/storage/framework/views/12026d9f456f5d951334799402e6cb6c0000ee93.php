

<?php $__env->startSection('content'); ?>

     <?php echo $__env->make('components.trending', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container mt-5" >
        <hr>
    </div>

     <?php echo $__env->make('components.comingsoon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


     <div class="container mt-5" >
        <hr>
    </div>

    <!-- <?php echo $__env->make('components.popular', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="container mt-5" >
        <hr>
    </div>

    <?php echo $__env->make('components.allTimePopular', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container mt-5" >
        <br>
    </div> -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\discover-anime\resources\views/home.blade.php ENDPATH**/ ?>