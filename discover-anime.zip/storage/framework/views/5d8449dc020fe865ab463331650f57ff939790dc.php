
<div class="container extra-padding-container">
    <div class="row heading-row-title">
        <div class="col-md-10">
            <h2>All Time Popular</h2>
            
        </div>
        <div class="col-md-2">

            <p class="view-all-text"><a href="<?php echo e(route('home')); ?>">View all</a></p>
            
        </div>
    </div>
    

    <div class="row">   

        <div class="col-md-3 anime-grid-list">

            <a href="">
            <img src="https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx16498-C6FPmWm59CyP.jpg"
             alt="" class="anime-grid-list-image">
            </a>

            <a href="" class="text-decor">
                <p class="anime-title-list-grid">Attack On Titan</p>
            </a>
            
        </div>
 
        <div class="col-md-3 anime-grid-list">

            <a href="" >
            <img src="https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx101922-PEn1CTc93blC.jpg"
             alt="" class="anime-grid-list-image">
            </a>

            <a href="" class="text-decor">
                <p class="anime-title-list-grid">Demon Slayer</p>
            </a>
        </div>
 
        <div class="col-md-3 anime-grid-list">

            <a href="">
            <img src="https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx1535-lawCwhzhi96X.jpg"
             alt="" class="anime-grid-list-image">
            </a>
              <a href="" class="text-decor">
                <p class="anime-title-list-grid">Death Note</p>
            </a>
        </div>
   
       
        <div class="col-md-3 anime-grid-list">

            <a href="">
            <img src="https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx21459-DUKLgasrgeNO.jpg"
             alt="" class="anime-grid-list-image">
            </a>
              <a href="" class="text-decor">
                <p class="anime-title-list-grid">My Hero Academia Season 6</p>
            </a>
        </div>

        
    </div>
</div><?php /**PATH C:\xampp\htdocs\Laravel\discover-anime\resources\views/components/allTimePopular.blade.php ENDPATH**/ ?>