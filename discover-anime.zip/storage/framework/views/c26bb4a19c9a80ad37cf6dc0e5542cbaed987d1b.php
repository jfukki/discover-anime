<div class="container-fluid extra-padding-container my-footer mt-5">
  <footer class="row row-cols-5 py-5  border-top">
    <div class="col">
      <a href="/" class="d-flex align-items-center mb-3 link-dark text-decoration-none">
        <!-- <svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"></use></svg> -->
        <h2 class="footer-color">Discover & Explore Anime</h2>
      </a>
      <p class=" footer-color">© 2021</p>
    </div>

    <div class="col">

    </div>

    <div class="col">
      <h5>Section</h5>
      <ul class="nav flex-column ">
        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 footer-color">Home</a></li>
        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 footer-color">Features</a></li>
        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 footer-color">Pricing</a></li>
        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 footer-color">FAQs</a></li>
        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 footer-color">About</a></li>
      </ul>
    </div>

    <div class="col">
      <h5>Section</h5>
      <ul class="nav flex-column">
        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 footer-color">Home</a></li>
        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 footer-color">Features</a></li>
        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 footer-color">Pricing</a></li>
        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 footer-color">FAQs</a></li>
        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 footer-color">About</a></li>
      </ul>
    </div>

    <div class="col">
      <h5>Section</h5>
      <ul class="nav flex-column">
        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 footer-color">Home</a></li>
        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 footer-color">Features</a></li>
        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 footer-color">Pricing</a></li>
        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 footer-color">FAQs</a></li>
        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 footer-color">About</a></li>
      </ul>
    </div>
  </footer>
</div><?php /**PATH C:\xampp\htdocs\Laravel\discover-anime\resources\views/layouts/footer.blade.php ENDPATH**/ ?>